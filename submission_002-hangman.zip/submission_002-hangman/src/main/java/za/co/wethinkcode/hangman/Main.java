package za.co.wethinkcode.hangman;

public class Main {

    public static void main(String[] args){
//        HangMan run = new HangMan();
//        run.runHangman();
    }

}
